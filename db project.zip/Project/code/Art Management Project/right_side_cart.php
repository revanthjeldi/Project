<div class="col-md-3 my_cart_container">
	<div class="my_cart">
        <h3>MyCart</h3>
		<div class="cart_items">
			<ol>

		</ol>
        </div>
	</div>
</div>	